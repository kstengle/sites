/*------------------------------------------------------------------------------
 * Project Name: LACES
 * Client Name: American Society of Landscape Architects(ASLA)
 * Component Name: CourseList.aspx.cs
 * Purpose/Function: Display Provider welcome page with courselist related to loggedin provider
 * Author: Matiur Rahman
 * Version              Author              Date            Reason
 * 1.0              Matiur Rahman       01/08/2008      Create this Page with initial requirements
 --------------------------------------------------------------------------------*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using Pantheon.ASLA.LACES.Common;
using Pantheon.ASLA.LACES.DataAccess;
using System.Diagnostics;

/// <summary>
/// Provider Welcome / Course Listing
/// </summary>
public partial class Provider_ProviderCourseList : ProviderBasePage
{
    protected int hrcount = 1;
    protected IList<Course> coursesRelatedtoProvider = new List<Course>();
    /// <summary>
    /// Page load event
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            CourseDataAccess objCourseDAL = new CourseDataAccess();
            //Provider provider = (Provider)Session[LACESConstant.SessionKeys.LOGEDIN_PROVIDER];
            if (Request.QueryString["status"] == null)
            {
                populateCourseStatusList("");
                ApprovedProvider provider = (ApprovedProvider)Session[LACESConstant.SessionKeys.LOGEDIN_APPROVED_PROVIDER];
                coursesRelatedtoProvider = objCourseDAL.GetCoursesByProviderId(provider.ID, "T");

                ///Populate Course Data List
                dlCourseList.DataSource = coursesRelatedtoProvider;
                dlCourseList.DataBind();

                if (coursesRelatedtoProvider.Count < 1)
                {
                    dlCourseList.Visible = false;
                    NoResult.Visible = true;
                }
            }
            else
            {
                populateCourseStatusList(Request.QueryString["status"]);
                FilterCoursesBind("", "", "", "", "", Request.QueryString["status"]);
            }
            populateStateList();
            populateSubjectList();
        }
    }

    /// <summary>
    /// Redirect to Add New Course Page
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAddNewCourses_Click(object sender, EventArgs e)
    {
        Response.Redirect("CourseDetails.aspx");
    }

    /// <summary>
    /// OnItemCreated event call this method to populate formatted "Start Date", "End Date" and "Course Title"
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>    
    protected void dlCourseList_ItemCreated(object sender, RepeaterItemEventArgs e)
    {
        RepeaterItem dlItem = e.Item;
        if (dlItem.DataItem != null)
        {            
            ///Populate Start Date field
            Label lblStartDate = (Label)dlItem.FindControl("lblStartDate");
            if (lblStartDate != null)
            {
                DateTime startDate = Convert.ToDateTime(DataBinder.Eval(dlItem.DataItem, "StartDate"));
                lblStartDate.Text = startDate.ToString("MM/dd/yyyy");
                //if (DateTime.Today >= startDate)
                //    lblStartDate.CssClass = "dateBold";
            }

            ///Populate End Date field
            Label lblEndDate = (Label)dlItem.FindControl("lblEndDate");
            if (lblEndDate != null)
            {
                DateTime endDate = Convert.ToDateTime(DataBinder.Eval(dlItem.DataItem, "EndDate"));
                lblEndDate.Text = endDate.ToString("MM/dd/yyyy");
                //if (DateTime.Today >= endDate)
                //    lblEndDate.CssClass = "dateBold";
            }

            ///Populate Course Title linked to Course Details page
            Label lblTitle = (Label)dlItem.FindControl("lblTitle");
            if (lblTitle != null)
            {
                ///Html encode the title text
                string title = Server.HtmlEncode(DataBinder.Eval(dlItem.DataItem, "Title").ToString());
                string courseId = DataBinder.Eval(dlItem.DataItem, "ID").ToString();
                lblTitle.Text = "<a href='CourseDetails.aspx?CourseID=" + courseId + "'>" + title + "</a>";
            }

            Label lblStatus = (Label)dlItem.FindControl("lblStatus");
            LinkButton btnStatus = (LinkButton)dlItem.FindControl("btnStatus");

            if (lblStatus != null)
            {
                ///Html encode the title text
                string status = Server.HtmlEncode(DataBinder.Eval(dlItem.DataItem, "Status").ToString().Trim());
                switch (status)
                {
                    case "CL":
                        status = "Closed";
                        break;
                    case "IC":
                        status = "Action Required";
                        break;
                    case "NP":
                        status = "Pending Approval";
                        break;
                    case "OP":
                        status = "Open";
                        break;
                    case "PT":
                        status = "Archived";
                        break;

                }
                if (status.Trim() == "Open")
                {
                    if (btnStatus != null)
                    {
                        btnStatus.Text = "Close Enrollment";
                        //btnStatus.CommandArgument = DataBinder.Eval(dlItem.DataItem, "id").ToString();
                        //btnStatus.CommandName = "Close Enrollment";
                    }
                    lblStatus.Text = "Active";
                }
                else if (status.Trim() == "Closed")
                {
                    if (btnStatus != null)
                    {
                        btnStatus.Text = "Open Enrollment";
                        //btnStatus.CommandArgument = DataBinder.Eval(dlItem.DataItem, "ID").ToString();
                        //btnStatus.CommandName = "Open Enrollment";
                    }
                    lblStatus.Text = "Enrollments are closed";
                }
                else
                {
                    lblStatus.Text = status.Trim();
                    if (btnStatus != null)
                        btnStatus.Visible = false;
                }
            }
            /*Start of section RegistrationEligibility*/
            //Label lblRegistrationEligibility = (Label)dlItem.FindControl("lblRegistrationEligibility");
            //string registrationEligibility = string.Empty;
            //if (lblRegistrationEligibility != null)
            //{
            //    ///Html encode the lblRegistrationEligibility text
            //    registrationEligibility = Server.HtmlEncode(DataBinder.Eval(dlItem.DataItem, "RegistrationEligibility").ToString());
            //    registrationEligibility=registrationEligibility.Trim();
            //    registrationEligibility = registrationEligibility.Replace("\n", "<br/>");                
            //    lblRegistrationEligibility.Text = registrationEligibility;
            //}
            //if (registrationEligibility == string.Empty)
            //{
            //    HtmlTableRow trRegistrationEligibility = (HtmlTableRow)dlItem.FindControl("trRegistrationEligibility");
            //    if (trRegistrationEligibility != null)
            //    {
            //        trRegistrationEligibility.Attributes.Add("style", "display:none;"); //display iRegistrationEligibility
            //    }
            //}
            /*End of section RegistrationEligibility*/
            /*Start Active*/
            LinkButton uilbActiveButton = (LinkButton)dlItem.FindControl("uilbActiveButton");
            if (DataBinder.Eval(dlItem.DataItem, "Active").ToString() == "T")
            {
                uilbActiveButton.Text = "De-activate";
            }
            else
            {
                uilbActiveButton.Text = "Activate";
            }
            // = DataBinder.Eval(dlItem.DataItem, "Active").ToString();



        }
    }

    /// <summary>
    /// Get formatted location string with city and state
    /// </summary>
    /// <param name="course"></param>
    /// <returns></returns>
    protected string getFormattedLocation(string City, string StateProvince)
    {
        ///If State is empty
        if (StateProvince.Trim() == string.Empty)
            return Server.HtmlEncode(City);
        ///If city is empty
        else if (City == string.Empty)
            return StateProvince;
        ///If city and state both exist
        else
            return Server.HtmlEncode(City) + ", " + StateProvince;

    }
    private void populateCourseStatusList(string strFilter)
    {
        CourseStatusDataAccess courseStatusDAL = new CourseStatusDataAccess();
        IList<CourseStatus> courseStatusList = courseStatusDAL.GetAllCourseStatus(); // Get All course Status

        foreach (CourseStatus courseStatus in courseStatusList)
        {
            ListItem item = new ListItem(courseStatus.Notes, courseStatus.StatusCode, true);
            if(strFilter.Length==0 || strFilter.IndexOf(courseStatus.StatusCode)>=0)
            {
            item.Selected = true;
            }
            uiChxBoxListStatus.Items.Add(item);
            
        }

    }
    protected void FilterCourses(object sender, EventArgs e)
    {
        
      
        string strStatus = "";
        foreach (ListItem li in uiChxBoxListStatus.Items)
        {
            if (li.Selected)
            {
                strStatus += strStatus.Length == 0 ? li.Value : "," + li.Value;
            }
        }
        string strStartDate = uiTxtStartDate.Text;
        string strEndDate = uiTxtEndDate.Text;
        string strKeyword = uiTxtKeyword.Text;
        string strState = drpState.SelectedValue;
        string strSubject = drpSubject.SelectedValue;
        FilterCoursesBind(strStartDate,strEndDate,strKeyword,strState,strSubject,strStatus);
        
    }
    protected void FilterCoursesBind(string strStartDate, string strEndDate, string strKeyword, string strState, string strSubject, string strStatus)
    {
        int totalCount = 0;
        ApprovedProvider provider = (ApprovedProvider)Session[LACESConstant.SessionKeys.LOGEDIN_APPROVED_PROVIDER];
        CourseDataAccess objCourseDAL = new CourseDataAccess();
        IList<Course> courseResult = new List<Course>();
        courseResult = objCourseDAL.GetPagedCourseBySearchByProvider(strStartDate, strEndDate, strKeyword, 0, 10000, strStatus, provider.ID, strSubject, strState, ref totalCount);
        if (courseResult.Count < 1)
        {
            dlCourseList.Visible = false;
            NoResult.Visible = true;
        }
        else
        {
            dlCourseList.Visible = true;
            NoResult.Visible = false;
            dlCourseList.DataSource = courseResult;
            dlCourseList.DataBind();
        }
    }
    #region btnStatus_OnClick

    /// <summary>
    /// Call every time when click on the open close link button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnStatus_OnClick(object sender, EventArgs e)
    {
        LinkButton openCloseButton = sender as LinkButton;

        try
        {
            long courseID = Convert.ToInt32(openCloseButton.CommandArgument);
            string status = openCloseButton.CommandName;

            CourseDataAccess oCourseDataAccess = new CourseDataAccess();

            if (status == "Open")
            {
                oCourseDataAccess.ChangeCourseStatus(courseID, "Closed");
            }
            else if (status == "Closed")
            {
                oCourseDataAccess.ChangeCourseStatus(courseID, "Open");
            }
        }
        catch
        {
        }
        Response.Redirect(Request.Url.AbsoluteUri);
    }
    protected void btnRenew_OnClick(object sender, EventArgs e)
    {
        LinkButton openCloseButton = sender as LinkButton;

        try
        {
            long courseID = Convert.ToInt32(openCloseButton.CommandArgument);
            string status = openCloseButton.CommandName;

            CourseDataAccess oCourseDataAccess = new CourseDataAccess();

            if (status == "Renew")
            {
                Session["ReplicateCourseID"] = courseID.ToString();
                Response.Redirect("coursedetails.aspx?RenewCourse=Y");
            }
        }
        catch
        {
        }
        Response.Redirect(Request.Url.AbsoluteUri);
    }

    protected void btnReplicate_OnClick(object sender, EventArgs e)
    {
        LinkButton openCloseButton = sender as LinkButton;

        try
        {
            long courseID = Convert.ToInt32(openCloseButton.CommandArgument);
            string status = openCloseButton.CommandName;

            CourseDataAccess oCourseDataAccess = new CourseDataAccess();

            if (status == "Replicate")
            {
                Session["ReplicateCourseID"] = courseID.ToString();
                Response.Redirect("coursedetails.aspx?ReplicateCourse=Y");
            }
        }
        catch
        {
        }
        Response.Redirect(Request.Url.AbsoluteUri);
    }

    #endregion
    #region btnStatus_OnClick

    /// <summary>
    /// Call every time when click on the open close link button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnActive_OnClick(object sender, EventArgs e)
    {
        LinkButton openCloseButton = sender as LinkButton;

        try
        {
            long courseID = Convert.ToInt32(openCloseButton.CommandArgument);
            string status = openCloseButton.CommandName;

            CourseDataAccess oCourseDataAccess = new CourseDataAccess();

            if (status == "T")
            {
                oCourseDataAccess.ChangeCourseActive(courseID, "F");
            }
            else if (status == "F")
            {
                oCourseDataAccess.ChangeCourseActive(courseID, "T");
            }
        }
        catch
        {
        }
        Response.Redirect(Request.Url.AbsoluteUri);
    }

    #endregion
    #region Populate State List
    /// <summary>
    ///  Populate State List 
    /// </summary>
    private void populateStateList()
    {
        StateDataAccess stateDAL = new StateDataAccess();
        string webroot = LACESUtilities.GetApplicationConstants("ASLARoot");
        int StateProvidenceID = int.Parse(LACESUtilities.GetApplicationConstants("StateProvinceContentID"));
        IList<State> stateList = stateDAL.GetAllStates(StateProvidenceID, webroot); // Get all States 

        ListItem defaultItem = new ListItem("- State List -", "");
        drpState.Items.Add(defaultItem);

        foreach (State state in stateList)
        {
            ListItem item = new ListItem(state.StateName, state.StateCode);
            drpState.Items.Add(item);
        }

        //for other International value
        drpState.Items.Add(new ListItem("- Other International -", "OI"));
    }
    #endregion

    #region Populate Subject List
    /// <summary>
    ///  Populate Subject List 
    /// </summary>
    private void populateSubjectList()
    {
        SubjectDataAccess subjectDAL = new SubjectDataAccess();
        string webroot = LACESUtilities.GetApplicationConstants("ASLARoot");
        int SubjectID = int.Parse(LACESUtilities.GetApplicationConstants("SubjectContentID"));
        IList<Subject> subjectList = subjectDAL.GetAllSubjects(SubjectID, webroot); // Get all Subjects

        foreach (Subject subject in subjectList)
        {
            ListItem item = new ListItem(subject.SubjectName, subject.SubjectID.ToString());
            drpSubject.Items.Add(item);
        }
    }
    #endregion

}
