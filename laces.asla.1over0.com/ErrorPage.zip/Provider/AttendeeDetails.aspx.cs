/*------------------------------------------------------------------------------
 * Project Name: LACES
 * Client Name: ASLA
 * Component Name: AttendeeDetails.aspx
 * Purpose/Function: This is Details of Participants Page
 * 
 * Author: Wasim Majid
 * Version              Author            Date         Reason 
 * 1.0                 Wasim Majid      01/15/2008     Page Creation
 * 1.1                 Alamgir Hossain  05/09/2008     Work on Enhancement 2 
 --------------------------------------------------------------------------------*/

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Provider_AttendeeDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
