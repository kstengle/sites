// jQuery Scripts

$(document).ready(function() {
    
    $('.searchHelpLink').click(function() {
        $('#searchHelp').show();
    });
    
    $('#closeBox').click(function() {
        $('#searchHelp').hide();
    });
    
});
